/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/23 19:33:03 by rchiam            #+#    #+#             */
/*   Updated: 2025/03/23 21:41:56 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_2_digit_output(int i);

void	ft_print_comb2(void)
{
	int	a;
	int	b;

	a = 0;
	while (a < 99)
	{
		b = a + 1;
		while (b <=99)
		{
			ft_print_2_digit_output(a);
			write(1, " ", 1);
			ft_print_2_digit_output(b);
			if (a != 98 && b != 99)
			{
				write(1, ", ", 2);
			}
			b ++;
		}
		a ++;
	}
}

void	ft_print_2_digit_output(int i)
{
	char i_10_place;
	char i_0_place;

	if (i < 10)
	{
		i_10_place = '0';
		i_0_place = '0' + i;
	}
	else
	{
		i_10_place = (i/10) + '0';
		i_0_place = (i%10) + '0';
	}
	write(1, &i_10_place, 1);
	write(1, &i_0_place, 1);
}

int	main()
{
	ft_print_comb2();
}