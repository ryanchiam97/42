/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/03 19:05:28 by rchiam            #+#    #+#             */
/*   Updated: 2025/04/07 20:55:00 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_ultimate_range(int **range, int min, int max)
{
	int	size;
	int	i;

	if (max <= min)
	{
		*range = NULL;
		return (0);
	}
	size = max - min;
	*range = (int *) malloc(size * (sizeof(int)));
	if (*range == NULL)
		return (-1);
	i = 0;
	while (i < size)
	{
		(*range)[i] = min;
		min++;
		i++;
	}
	return (size);
}

// #include <stdio.h>
// int main()
// {
// 	int i = 0;
// 	int *arr;
// 	int size = ft_ultimate_range(&arr, 0, );
// 	printf("%i", size);
// 	return (0);
// }