/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/03 19:31:43 by rchiam            #+#    #+#             */
/*   Updated: 2025/04/07 20:57:13 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
// #include <stdio.h>

char	*ft_strcat(char *dest, char	*src)
{
	int	i;
	int	src_count;

	i = 0;
	src_count = 0;
	while (dest[i])
	{
		i ++;
	}
	while (src[src_count])
	{
		dest[i + src_count] = src[src_count];
		src_count ++;
	}
	dest[i + src_count] = '\0';
	return (dest);
}

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		i++;
	}
	return (i);
}

char	*do_join(char *output, char**strs, char *sep, int size)
{
	int	i;

	i = 0;
	while (i < size)
	{
		if (strs[i] != NULL)
			output = ft_strcat(output, strs[i]);
		if (i < (size - 1))
			output = ft_strcat(output, sep);
		i++;
	}
	return (output);
}

char	*do_malloc(char *output, char *sep, int size, int total_len)
{
	int	i;

	output = malloc(total_len + (ft_strlen(sep) * (size - 1) + 1));
	if (output == NULL)
		return (NULL);
	i = 0;
	output[i] = '\0';
	return (output);
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	char	*output;
	int		i;
	int		total_len;

	output = NULL;
	if (size == 0)
	{
		output = malloc(1);
		*output = 0;
		return (output);
	}
	i = 0;
	total_len = 0;
	while (i < size)
	{
		if (strs[i] != NULL)
			total_len += ft_strlen(strs[i]);
		i++;
	}
	output = do_malloc(output, sep, size, total_len);
	return (do_join(output, strs, sep, size));
}

// #include <stdio.h>
// int main() {
//     char *strs1[] = {"Hello", "world", "!"};
//     char *sep1 = ", ";
//     char *result1 = ft_strjoin(3, strs1, sep1);
//     printf("Test 1: %s\n", result1);  // "Hello, world, !"
//     free(result1);

//     char *strs2[] = {"One"};
//     char *sep2 = "---";
//     char *result2 = ft_strjoin(1, strs2, sep2);
//     printf("Test 2: %s\n", result2);  // "One"
//     free(result2);

//     char *strs3[] = {NULL, "test", NULL};
//     char *sep3 = "-";
//     char *result3 = ft_strjoin(3, strs3, sep3);
//     printf("Test 3: %s\n", result3);  // "-test-"
//     free(result3);

//     char *result4 = ft_strjoin(0, NULL, NULL);
//     printf("Test 4: %s\n", result4);  // ""
//     free(result4);

// 	char *strs5[] = {"", "", ""};
//     char *sep5 = "asdasdasd";
// 	char *result5 = ft_strjoin(3, strs5, sep5);
//     printf("Test 5: %s\n", result5);  // ""
//     free(result5);
//     return 0;
// }
