/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/02 23:04:40 by rchiam            #+#    #+#             */
/*   Updated: 2025/04/07 20:53:59 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int	size;
	int	*output;
	int	i;

	if (max <= min)
		return (NULL);
	size = max - min;
	output = (int *) malloc(size * (sizeof(int)));
	if (output == NULL)
		return (NULL);
	i = 0;
	while (i < size)
	{
		output[i] = min;
		min++;
		i++;
	}
	return (output);
}
// #include <stdio.h>
// int main()
// {
// 	int i = 0;
// 	int *arr = ft_range(-5, 5);
// 	while(arr[i])
// 	{
// 		printf("%i",arr[i]);
// 		i++;
// 	}
// }