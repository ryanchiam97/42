/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/01 18:50:59 by rchiam            #+#    #+#             */
/*   Updated: 2025/04/01 20:45:31 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_factorial(int nb)
{
	int	output;

	if (nb < 0)
		return (0);
	else if (nb == 1 || nb == 0)
		return (1);
	output = 1;
	while (nb >= 2)
	{
		output *= nb;
		nb--;
	}
	return (output);
}
