/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/01 19:08:20 by rchiam            #+#    #+#             */
/*   Updated: 2025/04/01 20:45:57 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterate(int nb, int power)
{
	int	output;

	output = 1;
	while (power >= 1)
	{
		output *= nb;
		power --;
	}
	return (output);
}

int	ft_iterative_power(int nb, int power)
{
	if (power < 0)
		return (0);
	if (power == 0)
		return (1);
	return (ft_iterate(nb, power));
}
