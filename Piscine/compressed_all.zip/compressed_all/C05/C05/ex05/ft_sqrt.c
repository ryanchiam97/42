/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sqrt.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/01 20:17:23 by rchiam            #+#    #+#             */
/*   Updated: 2025/04/01 20:48:45 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	check_sqrt(int i, int nb)
{
	if (i > nb / 2 || i * i > nb)
		return (0);
	if (i * i == nb)
		return (i);
	else
		return (check_sqrt(i + 1, nb));
}

int	ft_sqrt(int nb)
{
	if (nb == 1)
		return (1);
	if (nb < 4)
		return (0);
	return (check_sqrt(2, nb));
}
