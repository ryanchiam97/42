/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlowcase.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/25 21:17:32 by rchiam            #+#    #+#             */
/*   Updated: 2025/03/25 22:13:05 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>
char	*ft_strlowcase(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (str[i] >= 'A' && str[i] <= 'Z')
		{
			str[i] = str[i] + 32;
		}
		i ++;
	}
	return (str);
}

// int main()
// {
// 	char str1[] = "atyejrtaa";
// 	char str2[] = "AAAAAAaaaAAA";
// 	char str3[] = "4633twefaaDDDDD";
// 	char str4[] = "";
// 	printf("%s\n", ft_strlowcase(str1));
// 	printf("%s\n", ft_strlowcase(str2));
// 	printf("%s\n", ft_strlowcase(str3));
// 	printf("%s\n", ft_strlowcase(str4));
// }
