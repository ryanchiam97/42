/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/25 19:43:39 by rchiam            #+#    #+#             */
/*   Updated: 2025/03/25 20:34:23 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>

int	ft_str_is_alpha(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (str[i] < 65 || str[i] > 122)
		{
			return (0);
		}
		if (str[i] > 90 && str[i] < 97)
		{
			return (0);
		}
		i ++;
	}
	return (1);
}

// int	main(void)
// {
// 	printf("%i", ft_str_is_alpha("oiu000ytrewq"));
// 	printf("%i", ft_str_is_alpha("oiAAAuywq"));
// 	printf("%i", ft_str_is_alpha("oi3z"));
// 	printf("%i", ft_str_is_alpha("AA"));
// 	printf("%i", ft_str_is_alpha("ZZ"));
// 	printf("%i", ft_str_is_alpha("a"));
// 	printf("%i", ft_str_is_alpha("z"));
// 	printf("%i", ft_str_is_alpha(""));
// 	return 0;
// }
