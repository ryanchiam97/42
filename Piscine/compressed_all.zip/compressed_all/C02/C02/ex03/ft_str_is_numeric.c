/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/25 20:25:44 by rchiam            #+#    #+#             */
/*   Updated: 2025/03/25 20:45:47 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>
int	ft_str_is_numeric(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (str[i] < '0' || str[i] > '9')
		{
			return (0);
		}
		i ++;
	}
	return (1);
}

// int main()
// {
// 	printf("%i\n", ft_str_is_numeric("987654"));
// 	printf("%i\n", ft_str_is_numeric("987a54"));
// 	printf("%i\n", ft_str_is_numeric("f87654"));
// 	printf("%i\n", ft_str_is_numeric(""));
// }