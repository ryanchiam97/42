/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/25 21:22:07 by rchiam            #+#    #+#             */
/*   Updated: 2025/04/03 20:11:51 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_new_word_checker(char c)
{
	if (c >= 'A' && c <= 'Z')
		return (0);
	if (c >= 'a' && c <= 'z')
		return (0);
	if (c >= '0' && c <= '9')
		return (0);
	return (1);
}

char	*ft_strcapitalize(char	*str)
{
	int	new_word;
	int	i;

	new_word = 1;
	i = 0;
	while (str[i] != '\0')
	{
		if (new_word && (str[i] >= 'a' && str[i] <= 'z'))
		{
			if (str[i] >= 'a' && str[i] <= 'z')
				str[i] -= 32;
			new_word = 0;
		}
		else if (!new_word && (str[i] >= 'A' && str[i] <= 'Z'))
			str[i] += 32;
		else if (new_word && (str[i] >= 'A' && str[i] <= 'Z'))
			new_word = 0;
		if (ft_new_word_checker(str[i]) == 1)
			new_word = 1;
		i ++;
	}
	return (str);
}
// #include<stdio.h>

// int	main()
// {
// 	char str1[] = "         hello there";
// 	ft_strcapitalize(str1);
// 	printf("%s\n", str1);
// 	char str2[] = "HELLO";
// 	ft_strcapitalize(str2);
// 	printf("%s\n", str2);
// 	char str3[] = "salut, comment tu vas ? 42mots quarante-deux; cinquante+et+un";
// 	ft_strcapitalize(str3);
// 	printf("%s", str3);
// 	return 0;
// }
