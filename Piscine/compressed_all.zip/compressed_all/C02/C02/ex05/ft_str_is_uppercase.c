/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/25 20:51:33 by rchiam            #+#    #+#             */
/*   Updated: 2025/03/25 21:15:02 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>
int	ft_str_is_uppercase(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (str[i] < 'A' || str[i] > 'Z')
		{
			return (0);
		}
		i ++;
	}
	return (1);
}

// int main()
// {
// 	printf("%i\n", ft_str_is_uppercase("AAAAAAAAAA"));
// 	printf("%i\n", ft_str_is_uppercase("AAAAAAAa"));
// 	printf("%i\n", ft_str_is_uppercase(""));
// 	printf("%i\n", ft_str_is_uppercase("AAAAAAAAA-"));
// }