/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strupcase.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/25 20:58:59 by rchiam            #+#    #+#             */
/*   Updated: 2025/03/25 22:12:25 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>
char	*ft_strupcase(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (str[i] >= 'a' && str[i] <= 'z')
		{
			str[i] = str[i] - 32;
		}
		i ++;
	}
	return (str);
}

// int main()
// {
// 	char str1[] = "atyejrtaa";
// 	char str2[] = "AAAAAAaaaAAA";
// 	char str3[] = "4633twefaaDDDDD";
// 	char str4[] = "";
// 	printf("%s\n", ft_strupcase(str1));
// 	printf("%s\n", ft_strupcase(str2));
// 	printf("%s\n", ft_strupcase(str3));
// 	printf("%s\n", ft_strupcase(str4));
// }