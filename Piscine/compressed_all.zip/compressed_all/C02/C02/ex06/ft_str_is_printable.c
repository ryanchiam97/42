/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/25 20:54:52 by rchiam            #+#    #+#             */
/*   Updated: 2025/03/25 20:58:00 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>
int	ft_str_is_printable(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (str[i] < ' ' || str[i] > '~')
		{
			return (0);
		}
		i ++;
	}
	return (1);
}

// int main()
// {
// 	printf("%i\n", ft_str_is_printable("\n"));
// 	printf("%i\n", ft_str_is_printable("AA\tAAAAAa"));
// 	printf("%i\n", ft_str_is_printable("6iuygr3524"));
// }
