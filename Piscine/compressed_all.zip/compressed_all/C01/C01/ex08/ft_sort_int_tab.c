/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/10 21:23:28 by rchiam            #+#    #+#             */
/*   Updated: 2025/04/10 21:49:14 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_sort_int_tab(int *tab, int size)
{
	int	temp;
	int	sorted;
	int	i;

	sorted = 0;
	while (sorted == 0)
	{
		sorted = 1;
		i = 0;
		while(i < size)
		{
			if (i < size - 2 && tab[i] > tab[i+1])
			{
				temp = tab[i];
				tab[i] = tab[i - 1];
				tab[i - 1] = tab[i];
				sorted = 0;
			}
			i++;
		}
	}
}
#include<stdio.h>
int main()
{
	int tab[4] = {1, 2, 3, 4};
	ft_sort_int_tab(tab, 4);
	int i = 0;
	while(i < 4)
	{
		printf("%i", tab[i]);
	}
}