/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/30 23:05:41 by rchiam            #+#    #+#             */
/*   Updated: 2025/04/01 20:53:55 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>
int	ft_atoi(char	*str)
{
	int	i;
	int	sign;
	int	num_found;

	i = 0;
	sign = 0;
	num_found = 0;
	while (*str)
	{
		if (*str >= '0' && *str <= '9')
		{
			num_found = 1;
			i = (i * 10) + (*str - '0');
		}
		else if (*str != ' ' && *str != '+' && *str != '-' && num_found == 0)
			return (0);
		else if (num_found == 1)
			break ;
		else if (*str == '-')
			sign ++;
		str ++;
	}
	if (sign % 2 != 0)
		i = -i;
	return (i);
}

// int main()
// {
// 	char *s = "--+5432ab1";
// 	printf("\n%i", ft_atoi(s));
// }