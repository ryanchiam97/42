/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/30 22:05:24 by rchiam            #+#    #+#             */
/*   Updated: 2025/03/30 23:03:43 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putstr(char	*str)
{
	while (*str)
	{
		write(1, str, 1);
		str++;
	}
}
// int main(int argc, char **argv)
// {
// 	char *str1 = "Printing:";
// 	ft_putstr(str1);
// 	char *str = argv[1];
// 	ft_putstr(str);
// }
