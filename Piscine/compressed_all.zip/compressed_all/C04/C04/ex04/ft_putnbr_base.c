/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/31 19:13:33 by rchiam            #+#    #+#             */
/*   Updated: 2025/04/01 20:58:37 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include <unistd.h>

int	ft_check_base(char *base)
{
	int	i;
	int	j;

	if (!base)
		return (-1);
	i = 0;
	while (base[i] != '\0')
	{
		if (base[i] == '+' || base[i] == '-')
			return (-1);
		j = i + 1;
		while (base[j] != '\0')
		{
			if (base[j] == base[i])
				return (-1);
			j ++;
		}
		i ++;
	}
	if (i < 2)
	{
		return (-1);
	}
	return (i);
}

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

long	ft_handle_negative(long nbr, char *base)
{
	char	neg_char;

	if (nbr == 0)
		ft_putchar(base[0]);
	else if (nbr < 0)
	{
		nbr = -nbr;
		neg_char = '-';
		ft_putchar(neg_char);
	}
	return (nbr);
}

void	ft_putnbr_base(int nbr, char *base)
{
	int		basenum;
	char	reversed_result[32];
	int		i;
	long	lnbr;

	basenum = ft_check_base(base);
	i = 0;
	if (basenum == -1)
		return ;
	lnbr = (long)nbr;
	if (lnbr <= 0)
		lnbr = ft_handle_negative(lnbr, base);
	if (lnbr == 0)
		return ;
	while (lnbr > 0)
	{
		reversed_result[i] = base[lnbr % basenum];
		lnbr /= basenum;
		i++;
	}
	while (i >= 0)
	{
		ft_putchar(reversed_result[i - 1]);
		i--;
	}
}
// #include <stdio.h>
// int main() {
//     ft_putnbr_base(42, "0123456789"); // Decimal
//     printf("\n");
//     ft_putnbr_base(42, "01"); // Binary
//     printf("\n");
//     ft_putnbr_base(42, "0123456789ABCDEF"); // Hexadecimal
//     printf("\n");
//     ft_putnbr_base(-42, "0123456789"); // Negative Decimal
//     printf("\n");
//     ft_putnbr_base(0, "0123456789"); // 0
//     printf("\n");
//     ft_putnbr_base(-2147483648, "0123456789");
//     printf("\n");
//     ft_putnbr_base(2147483647, "0123456789");
//     printf("\n");
// 	   ft_putnbr_base(-2147483648, "01");
//     printf("\n");
//     return 0;
// }