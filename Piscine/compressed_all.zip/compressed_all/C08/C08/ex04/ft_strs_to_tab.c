/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strs_to_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/07 23:07:26 by rchiam            #+#    #+#             */
/*   Updated: 2025/04/10 12:26:59 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_stock_str.h"
#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		i++;
	}
	return (i);
}

char	*ft_strcpy(char *dest, char *src)
{
	char	*start;

	start = dest;
	while (*src)
	{
		*dest = *src;
		dest++;
		src++;
	}
	*dest = '\0';
	return (start);
}

char	*ft_strdup(char *src)
{
	char	*dest;

	dest = (char *)malloc(sizeof(char) * ft_strlen(src) + 1);
	if (dest == NULL)
		return (NULL);
	return (ft_strcpy(dest, src));
}

struct s_stock_str	*ft_strs_to_tab(int ac, char **av)
{
	int					i;
	t_stock_str	*output;
	t_stock_str	*output_end;

	i = 0;
	output = malloc((ac + 1)
			* sizeof(t_stock_str));
	if (!output)
		return (NULL);
	while (i < ac)
	{
		output[i].size = ft_strlen(av[i]);
		output[i].str = av[i];
		output[i].copy = ft_strdup(av[i]);
		i++;
	}
	output_end = output + i;
	output_end = 0;
	return (output);
}

// #include <stdio.h>

// int	main(int argc, char **argv)
// {
// 	struct s_stock_str	*tab;

// 	tab = ft_strs_to_tab(argc, argv);
// 	if (tab == NULL)
// 	{
// 		printf("Memory allocation failed for the structure array.\n");
// 		return (1);
// 	}
// 	while (tab != 0)
// 	{
// 		printf("%s\n", tab->str);
// 		printf("%s\n", tab->copy);
// 		printf("%i\n", tab->size);
// 		tab++;
// 	}
// 	// Free the allocated memory for copies
// 	return (0);
// }
