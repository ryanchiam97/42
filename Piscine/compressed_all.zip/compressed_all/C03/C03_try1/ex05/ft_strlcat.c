/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/27 22:10:52 by rchiam            #+#    #+#             */
/*   Updated: 2025/03/30 20:33:22 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	ft_strlcat(char	*dest, char	*src, unsigned int size)
{
	char			*start;
	unsigned int	i;

	start = dest;
	i = 0;
	while (dest)
	{
		dest++;
		i++;
	}
	while (i < size)
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (size);
}

// #include<stdio.h>
// int main()
// {
// 	char dest[8] = "Hello, ";
// 	char src[] = "world!";

// 	unsigned int result = ft_strlcat(dest, src, 3);

// //  Expected: "Hello, world!"
// 	printf("Resulting string: %s\n", dest); 
// //  Expected: 13 (length of "Hello, world!")
// 	printf("Total length: %d\n", result);	

// 	return 0;
// }