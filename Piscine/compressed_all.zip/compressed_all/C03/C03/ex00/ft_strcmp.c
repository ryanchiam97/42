/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/26 19:12:25 by rchiam            #+#    #+#             */
/*   Updated: 2025/03/26 20:43:54 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strcmp(char	*s1, char	*s2)
{
	int	i;

	i = 0;
	while (s1[i] && s2[i])
	{
		if (s1[i] != s2[i])
			return (s1[i] - s2[i]);
		else
			i++;
	}
	return (s1[i] - s2[i]);
}

// #include <stdio.h>
// int main()
// {
// 	char *str1 = "hi";
// 	char *str2 = "hi";
// 	printf("%i\n",ft_strcmp(str1, str2));

// 	char *str3 = "hi";
// 	char *str4 = "hiThere";
// 	printf("%i\n",ft_strcmp(str3, str4));

// 	char *str5 = "hi";
// 	char *str6 = "";
// 	printf("%i\n",ft_strcmp(str5, str6));

// 	char *str7 = "hihh";
// 	char *str8 = "hihhhh";
// 	printf("%i\n",ft_strcmp(str7, str8));
// 	return 0;
// }