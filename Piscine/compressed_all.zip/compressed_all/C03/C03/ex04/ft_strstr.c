/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/26 23:15:21 by rchiam            #+#    #+#             */
/*   Updated: 2025/03/30 20:33:06 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strstr(char *str, char *to_find)
{
	int	j;

	if (*to_find == '\0')
		return str;
	while (*str != 0)
	{
		j = 0;
		while (str[j] && to_find[j] && str[j] == to_find[j])
		{
			j++;
		}
		if (to_find[j] == '\0')
			return (str);
		str++;
	}
	return (0);
}
// #include <stdio.h>
// int	main(void)
// {
// 	char s1[] = "hello world!";
// 	char s2[] = "";
// 	printf("%p\n", s1 + 8);
// 	printf("%s\n", ft_strstr(s1, s2));
// 	printf("%p\n", ft_strstr(s1, s2));

// 	return (0);
// }