/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/26 20:42:02 by rchiam            #+#    #+#             */
/*   Updated: 2025/03/27 22:37:46 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcat(char *dest, char	*src)
{
	int	i;
	int	src_count;

	i = 0;
	src_count = 0;
	while (dest[i])
	{
		i ++;
	}
	while (src[src_count])
	{
		dest[i + src_count] = src[src_count];
		src_count ++;
	}
	dest[i + src_count] = '\0';
	return (dest);
}
