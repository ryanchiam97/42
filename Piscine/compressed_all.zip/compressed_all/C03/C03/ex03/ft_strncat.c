/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/26 23:11:47 by rchiam            #+#    #+#             */
/*   Updated: 2025/03/29 20:02:35 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	int				i;
	unsigned int	src_count;

	i = 0;
	src_count = 0;
	while (dest[i])
	{
		i++;
	}
	while (src[src_count] && (src_count < nb))
	{
		dest[i + src_count] = src[src_count];
		src_count++;
	}
	dest[i + src_count] = '\0';
	return (dest);
}
