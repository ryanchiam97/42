#include "check_unique.h"
#include <stdio.h>

int	main(void)
{
	int test1[4][4] = {
		{1, 2, 3, 4},
		{4, 3, 2, 1},
		{2, 1, 4, 3},
		{3, 4, 1, 2}}; // Unique rows and columns
	int test2[4][4] = {
		{1, 2, 3, 4},
		{1, 3, 2, 4},
		{2, 1, 4, 3},
		{3, 4, 1, 2}}; // First column is not unique
	int test3[4][4] = {
		{1, 2, 3, 4},
		{4, 3, 2, 1},
		{2, 1, 4, 3},
		{3, 4, 2, 2}}; // Last row is not unique
	printf("Test 1 - Unique Rows: %d, Unique Columns: %d\n",
			check_unique_rows(test1),
			check_unique_cols(test1));
	printf("Test 2 - Unique Rows: %d, Unique Columns: %d\n",
			check_unique_rows(test2),
			check_unique_cols(test2));
	printf("Test 3 - Unique Rows: %d, Unique Columns: %d\n",
			check_unique_rows(test3),
			check_unique_cols(test3));
	return (0);
}
