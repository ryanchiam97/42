/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_unique.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gutay <gutay@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/29 16:57:31 by gutay             #+#    #+#             */
/*   Updated: 2025/03/29 17:24:47 by gutay            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "check_unique.h"
#include <stdio.h>

int	check_unique_rows(int arr[4][4])
{
	int	i;
	int	cursor;
	int	row;

	row = 0;
	while (row < 4)
	{
		cursor = 0;
		i = 1;
		while (cursor < 3)
		{
			while (i < 4)
			{
				if (arr[row][cursor] == arr[row][i])
					return (0);
				i++;
			}
			cursor++;
			i = cursor + 1;
		}
		row++;
	}
	return (1);
}

int	check_unique_cols(int arr[4][4])
{
	int	i;
	int	cursor;
	int	col;

	col = 0;
	while (col < 4)
	{
		cursor = 0;
		i = 1;
		while (cursor < 3)
		{
			while (i < 4)
			{
				if (arr[cursor][col] == arr[i][col])
					return (0);
				i++;
			}
			cursor++;
			i = cursor + 1;
		}
		col++;
	}
	return (1);
}

/*
int	main(void)
{
	int test1[4][4] = {
		{1, 2, 3, 4},
		{4, 3, 2, 1},
		{2, 1, 4, 3},
		{3, 4, 1, 2}}; // Unique rows and columns
	int test2[4][4] = {
		{1, 2, 3, 4},
		{1, 3, 2, 4},
		{2, 1, 4, 3},
		{3, 4, 1, 2}}; // First column is not unique
	int test3[4][4] = {
		{1, 2, 3, 4},
		{4, 3, 2, 1},
		{2, 1, 4, 3},
		{3, 4, 2, 2}}; // Last row is not unique
	printf("Test 1 - Unique Rows: %d, Unique Columns: %d\n",
			check_unique_rows(test1),
			check_unique_cols(test1));
	printf("Test 2 - Unique Rows: %d, Unique Columns: %d\n",
			check_unique_rows(test2),
			check_unique_cols(test2));
	printf("Test 3 - Unique Rows: %d, Unique Columns: %d\n",
			check_unique_rows(test3),
			check_unique_cols(test3));
	return (0);
}
*/
