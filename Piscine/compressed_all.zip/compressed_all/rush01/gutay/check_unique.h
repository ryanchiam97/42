/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_unique.h                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gutay <gutay@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/29 17:26:01 by gutay             #+#    #+#             */
/*   Updated: 2025/03/29 17:26:06 by gutay            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CHECK_UNIQUE_H
# define CHECK_UNIQUE_H

int	check_unique_rows(int arr[4][4]);
int	check_unique_cols(int arr[4][4]);

#endif