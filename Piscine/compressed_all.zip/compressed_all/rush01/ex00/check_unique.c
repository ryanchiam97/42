/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_unique.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/29 16:57:31 by gutay             #+#    #+#             */
/*   Updated: 2025/03/29 20:34:03 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "check_unique.h"
#include <stdio.h>

int	check_unique_rows(int arr[4][4])
{
	int	i;
	int	cursor;
	int	row;

	row = 0;
	while (row < 4)
	{
		cursor = 0;
		i = 1;
		while (cursor < 3)
		{
			while (i < 4)
			{
				if (arr[row][cursor] == arr[row][i])
					return (0);
				i++;
			}
			cursor++;
			i = cursor + 1;
		}
		row++;
	}
	return (1);
}

int	check_unique_cols(int arr[4][4])
{
	int	i;
	int	cursor;
	int	col;

	col = 0;
	while (col < 4)
	{
		cursor = 0;
		i = 1;
		while (cursor < 3)
		{
			while (i < 4)
			{
				if (arr[cursor][col] == arr[i][col])
					return (0);
				i++;
			}
			cursor++;
			i = cursor + 1;
		}
		col++;
	}
	return (1);
}
