/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   height_check.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/29 19:10:21 by rchiam            #+#    #+#             */
/*   Updated: 2025/03/29 21:21:24 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "height_check.h"

int	check(int list[4], int input)
{
	int	i;
	int	sum;
	int	largest;

	largest = 0;
	i = 0;
	sum = 0;
	while (i < 4)
	{
		if (list[i] > largest)
		{
			largest = list[i];
			sum++;
		}
		i++;
	}
	if (sum == input)
		return (1);
	return (0);
}

int	check_dir(int row_col_index, int input, int arr[4][4], char dir)
{
	int	i;
	int	list[4];

	i = 0;
	while (i < 4)
	{
		if (dir == 'u')
			list[i] = arr[i][row_col_index];
		else if (dir == 'd')
			list[i] = arr[3 - i][row_col_index];
		else if (dir == 'l')
			list[i] = arr[row_col_index][i];
		else if (dir == 'r')
			list[i] = arr[row_col_index][3 - i];
		else
			return (-1);
		i++;
	}
	return (check(list, input));
}

int	check_cond(int arr[4][4], int cond[16])
{
	int	i;
	int	is_ok;

	i = 0;
	is_ok = 0;
	while (i < 16)
	{
		if (i < 4)
			is_ok += (check_dir(i, cond[i], arr, 'u') == 1);
		else if (i < 8)
			is_ok += (check_dir(i - 4, cond[i], arr, 'd') == 1);
		else if (i < 12)
			is_ok += (check_dir(i - 8, cond[i], arr, 'l') == 1);
		else
			is_ok += (check_dir(i - 12, cond[i], arr, 'r') == 1);
		i++;
	}
	if (is_ok == 16)
		return (1);
	return (0);
}

// #include <stdio.h>

// int	main(void)
// {
// 	// int	cond[16];

// 	int result[4][4] =
// 		{
// 			{1, 2, 3, 4},
// 			{2, 3, 4, 1},
// 			{3, 4, 1, 2},
// 			{4, 1, 2, 3},
// 		};
// 	// int result1[4][4] =
// 	// {
// 	// 	{1,2,3,4},
// 	// 	{2,3,4,1},
// 	// 	{3,4,1,2},
// 	// 	{3,1,2,0},
// 	// };
// 	// int result2[4][4] =
// 	// {
// 	// 	{1,2,3,4},
// 	// 	{2,3,4,1},
// 	// 	{3,4,1,2},
// 	// 	{0,0,2,3},
// 	// };
// 	int cond[16] = {4, 3, 2, 1, 1, 2, 2, 2, 4, 3, 2, 1, 1, 2, 2, 2};
// 	printf("check cond = %d\n", check_cond(result, cond));
// }
