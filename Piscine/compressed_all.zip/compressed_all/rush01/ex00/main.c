/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jia-lim <jia-lim@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/29 11:19:20 by jia-lim           #+#    #+#             */
/*   Updated: 2025/03/30 14:33:59 by jia-lim          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include "rush01.c"
#include "check_unique.h"
#include "solve.h"
#include <stdio.h>
#include <unistd.h>

/*
	if there is a space at the end, it will ignore
	if there is multiple consecutive space, it will just skip
*/
int	get_question(char *str, int *arr, int *size)
{
	int	consecutive_space;
	int	charcount;

	charcount = 0;
	consecutive_space = 0;
	while (*str != '\0')
	{
		charcount++;
		if (*str >= '1' && *str <= '4')
		{
			arr[*size] = *str - '0';
			str++;
			(*size)++;
			consecutive_space = 0;
		}
		else if (*str == ' ' && consecutive_space == 0)
		{
			consecutive_space = 1;
			str++;
		}
		else
			break ;
	}
	return (charcount);
}

void	print_result(int result[4][4])
{
	char	c;
	int		x;
	int		y;

	x = 0;
	y = 0;
	while (y < 4)
	{
		while (x < 4)
		{
			c = result[y][x] + '0';
			write(1, &c, 1);
			if (x < 3)
				write(1, " ", 1);
			x++;
		}
		write(1, "\n", 1);
		x = 0;
		y++;
	}
}

int	main(int argc, char *argv[])
{
	int	size;
	int	cond[16];
	int	result[4][4];
	int	charcount;

	size = 0;
	if (argc != 2)
	{
		write(1, "Error\n", 6);
		return (0);
	}
	charcount = get_question(argv[1], cond, &size);
	if (size != 16 || charcount != 31)
	{
		write(1, "Error\n", 6);
		return (0);
	}
	if (solve(0, result, cond) == 1)
		print_result(result);
	else
		write(1, "Error\n", 6);
	return (0);
}
