/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jia-lim <jia-lim@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/29 11:19:20 by jia-lim           #+#    #+#             */
/*   Updated: 2025/03/29 17:52:54 by jia-lim          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include "rush01.c"
#include <stdio.h>
#include <unistd.h>
#include "solve.c"
/*
	if there is a space at the end, it will ignore
	if there is multiple consecutive space, it will just skip
*/
void	get_question(char *str, int *arr, int *size)
{
	while (*str != '\0')
	{
		if (*str >= '1' && *str <= '4')
		{
			arr[*size] = *str - '0';
			str++;
			(*size)++;
		}
		else if (*str == ' ')
			str++;
		else
			break ;
	}
}

void	print_result(int result[4][4])
{
	char	c;
	int		x;
	int		y;

	x = 0;
	y = 0;
	while (y < 4)
	{
		while (x < 4)
		{
			c = result[y][x] +'0';
			write(1, &c, 1);
			if (x < 3)
				write(1, " ", 1);
			x++;
		}
		write(1, "\n", 1);
		x = 0;
		y++;
	}
}

int	check_answer(int arr[4][4])
{
	if (check_unique_rows(arr) == 0)
		return (0);
	if (check_unique_cols(arr) == 0)
		return (0);
	return (1);
}

int	is_finish(int arr[4][4][4])
{
	int	row;
	int	col;
	int	i;
	int	sum;

	row = 0;
	while (row < 4)
	{
		col = 0;
		while (col < 4)
		{
			i = 0;
			sum = 0;
			while (i < 4)
				sum += arr[row][col][i++];
			if (sum != 1)
				return (0);
			col++;
		}
		row++;
	}
	return (1);
}

int	get_num(int row, int col, int arr[4][4][4])
{
	int	i;
	int	sum;
	int	result;

	i = 0;
	sum = 0;
	result = 0;
	while (i < 4)
	{
		result += arr[row][col][i] * (i + 1);
		sum += arr[row][col][i++];
	}
	if (sum != 1)
		return (0);
	return (result);
}

// int	check_unique_rows(int arr[4][4]);
// int	check_unique_cols(int arr[4][4]);

// int	check_colup(int col, int colup, int arr[4][4]);
// int	check_coldown(int col, int coldown, int arr[4][4]);
// int	check_rowleft(int row, int colup, int arr[4][4]);
// int	check_rowright(int row, int coldown, int arr[4][4]);

int	solve(int nth, int arr[4][4], int cond[16]);

// //GuoChong: Anything below is what I wrote
// //insertion determinator

// void inserter(void){
// 	//Check any int = 1 or 4
// 		//if == 1, inserts 4 offset opposite of position name
// 		//if == 4, inserter 1 2 3 4 offset opposite of position name
		
// } 

// //Initalize playing field
// void initPlayingField(int size){
// 	int chart[size][size] = 0;
// 	int i = 0;
// 	int j = 0;

// 	while (chart[i][j]){
// 		chart[i][j]=
// 	}
// }

// int	main(int argc, char *argv[])
int	main(void)
{
	int size = 0;
	int cond[16];
	int argc = 2;
	char *argv[] = {"", "4 3 2 1 1 2 2 2 4 3 2 1 1 2 2 2"};
	if(argc != 2)
	{
		write(1, "Error\n", 6);
		return (0);
	}
	get_question(argv[1], cond, &size);
	if(size != 16)
	{
		write(1, "Error\n", 6);
		return (0);
	}
	int result[4][4];
	if (solve(0, result, cond) == 1)
		print_result(result);
	else
		write(1, "Error\n", 6);
	return (0);
}
