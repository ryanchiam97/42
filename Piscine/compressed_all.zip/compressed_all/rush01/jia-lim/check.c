/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/29 15:05:50 by jia-lim           #+#    #+#             */
/*   Updated: 2025/03/29 18:57:31 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// int	check(int row_col, int up_down, int input, int arr[4][4][4])
// {

// 	return (0);
// }


// int	check_colup(int col, int colup, int arr[4][4][4])
// {
// 	int	i;
// 	int	sum;
// 	int	largest;

// 	largest = 0;
// 	i = 0;
// 	sum = 0;
// 	while (i < 4)
// 	{
// 		if (get_num(i, col, arr) > largest)
// 		{
// 			largest = get_num(i, col, arr);
// 			sum++;
// 		}
// 		i++;
// 	}
// 	if (sum == colup)
// 		return (1);
// 	return (0);
// }

// int	check_coldown(int col, int coldown, int arr[4][4][4])
// {
// 	int	i;
// 	int	sum;
// 	int	largest;

// 	largest = 0;
// 	i = 3;
// 	sum = 0;
// 	while (i >= 0)
// 	{
// 		if (get_num(i, col, arr) > largest)
// 		{
// 			largest = get_num(i, col, arr);
// 			sum++;
// 		}
// 		i++;
// 	}
// 	if (sum == coldown)
// 		return (1);
// 	return (0);
// }


int	check_colup(int col, int colup, int arr[4][4])
{
	int	i;
	int	sum;
	int	largest;

	largest = 0;
	i = 0;
	sum = 0;
	while (i < 4)
	{
		if (arr[i][col] > largest)
		{
			largest = arr[i][col];
			sum++;
		}
		i++;
	}
	if (sum == colup)
		return (1);
	return (0);
}

int	check_coldown(int col, int coldown, int arr[4][4])
{
	int	i;
	int	sum;
	int	largest;

	largest = 0;
	i = 3;
	sum = 0;
	while (i >= 0)
	{
		if (arr[i][col] > largest)
		{
			largest = arr[i][col];
			sum++;
		}
		i--;
	}
	if (sum == coldown)
		return (1);
	return (0);
}

int	check_rowleft(int row, int colup, int arr[4][4])
{
	int	i;
	int	sum;
	int	largest;

	largest = 0;
	i = 0;
	sum = 0;
	while (i < 4)
	{
		if (arr[row][i] > largest)
		{
			largest = arr[row][i];
			sum++;
		}
		i++;
	}
	if (sum == colup)
		return (1);
	return (0);
}

int	check_rowright(int row, int coldown, int arr[4][4])
{
	int	i;
	int	sum;
	int	largest;

	largest = 0;
	i = 3;
	sum = 0;
	while (i >= 0)
	{
		if (arr[row][i] > largest)
		{
			largest = arr[row][i];
			sum++;
		}
		i--;
	}
	if (sum == coldown)
		return (1);
	return (0);
}

int	check_unique_rows(int arr[4][4])
{
	int	i;
	int cursor;
	int row;

	row = 0;
	while (row < 4)
	{
		cursor = 0;
		i = 1;
		while (cursor < 3)
		{
			while (i < 4)
			{
				if (arr[row][cursor] == arr[row][i])
					return (0);
				i++;
			}
			cursor++;
			i = cursor + 1;
		}
		row++;
	}
	return (1);
}

int	check_unique_cols(int arr[4][4])
{
	int	i;
	int cursor;
	int col;

	col = 0;
	while (col < 4)
	{
		cursor = 0;
		i = 1;
		while (cursor < 3)
		{
			while (i < 4)
			{
				if (arr[cursor][col] == arr[i][col])
					return (0);
				i++;
			}
			cursor++;
			i = cursor + 1;
		}
		col++;
	}
	return (1);
}

int	check_cond(int arr[4][4], int cond[16])
{
	int	i;

	i = 0;
	while (i < 16)
	{
		if (i < 4)
		{
			if(check_colup(i, cond[i], arr) == 0)
			{
				return (0);
			}
		}
		else if (i < 8)
		{
			if(check_coldown(i - 4, cond[i], arr) == 0)
			{
				return (0);
			}
		}
		else if (i < 12)
		{
			if(check_rowleft(i - 8, cond[i], arr) == 0)
			{
				return (0);
			}
		}
		else
		{
			if(check_rowright(i - 12, cond[i], arr) == 0)
			{
				return (0);
			}
		}
		i++;
	}
	return (1);
}

#include <stdio.h>
int main(void){

	//correct answer
	// int possibility1[4][4][4] =
	// {
	// 	{{1,0,0,0},{0,1,0,0},{0,0,1,0},{0,0,0,1}},
	// 	{{0,1,0,0},{0,0,1,0},{0,0,0,1},{1,0,0,0}},
	// 	{{0,0,1,0},{0,0,0,1},{1,0,0,0},{0,1,0,0}},
	// 	{{0,0,0,1},{1,0,0,0},{0,1,0,0},{0,0,1,0}},
	// };

	int result[4][4] = 
	{
		{1,2,3,4},
		{2,3,4,1},
		{3,4,1,2},
		{4,1,2,3},
	};
	int result2[4][4] = 
	{
		{1,2,3,4},
		{2,3,4,1},
		{3,4,1,2},
		{0,0,2,3},
	};
	int	cond[16] = {4, 3, 2, 1, 1, 2, 2, 2, 4, 3, 2, 1, 1, 2, 2, 2};
	printf("check cond = %d\n", check_cond(result, cond));

}
// 	// printf("colup = %d\n", check_colup(0,4,result));
// 	// printf("colup = %d\n\n", check_colup(0,1,result));

// 	// printf("coldown = %d\n", check_coldown(0,1,result));
// 	// printf("coldown = %d\n\n", check_coldown(0,2,result));

// 	// printf("rowleft = %d\n", check_rowleft(1,3,result));
// 	// printf("rowleft = %d\n\n", check_rowleft(1,2,result));

// 	// printf("rowright = %d\n", check_rowright(2,2,result));
// 	// printf("rowright = %d\n\n", check_rowright(2,4,result));


// 	// printf("check unique rows = %d\n", check_unique_rows(result));
// 	// printf("check unique rows = %d\n", check_unique_rows(result1));
// 	// printf("check unique rows = %d\n\n", check_unique_rows(result2));

// 	// printf("check unique cols = %d\n", check_unique_cols(result));
// 	// printf("check unique cols = %d\n", check_unique_cols(result1));
// 	// printf("check unique cols = %d\n", check_unique_cols(result2));



// }