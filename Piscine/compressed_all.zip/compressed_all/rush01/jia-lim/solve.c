/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   solve.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jia-lim <jia-lim@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/29 16:57:17 by jia-lim           #+#    #+#             */
/*   Updated: 2025/03/29 17:35:53 by jia-lim          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "check.c"

int	check_cond(int arr[4][4], int cond[16]);

void	update(int num, int nth, int arr[4][4])
{
	if (nth < 4)
		arr[0][nth] = num;
	else if (nth < 8)
		arr[1][nth - 4] = num;
	else if (nth < 12)
		arr[2][nth - 8] = num;
	else if (nth < 16)
		arr[3][nth - 12] = num;
}

int	solve(int nth, int arr[4][4], int cond[16])
{
	int	i;

	if (nth == 16)
	{
		if (check_unique_rows(arr) == 0)
			return (0);
		if (check_unique_cols(arr) == 0)
			return (0);
		if (check_cond(arr, cond) == 0)
			return (0);
		return (1);
	}
	else
	{
		i = 1;
		update(i, nth, arr);
		while (solve(nth + 1, arr, cond) == 0)
		{
			i++;
			update(i, nth, arr);
			if (i > 4)
				return (0);
		}
	}
	return (1);
}
