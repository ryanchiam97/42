#include <stdio.h>

#define N 9

void print_permutation(int *digits) {
    // Unrolled print loop
    putchar(digits[0] + '0');
    putchar(digits[1] + '0');
    putchar(digits[2] + '0');
    putchar(digits[3] + '0');
    putchar(digits[4] + '0');
    putchar(digits[5] + '0');
    putchar(digits[6] + '0');
    putchar(digits[7] + '0');
    putchar(digits[8] + '0');
    putchar('\n');
}

void generate_permutations(int *digits, int start, int end) {
    if (start == end) {
        print_permutation(digits);
        return;
    }

    // Pointer to current position
    int *current = digits + start;
    
    // Generate permutations recursively
    generate_permutations(digits, start + 1, end);
    
    // Pointer to swap position
    int *swap_pos = current + 1;
    
    while (swap_pos <= digits + end) {
        // Swap elements
        int temp = *current;
        *current = *swap_pos;
        *swap_pos = temp;
        
        generate_permutations(digits, start + 1, end);
        
        // Undo swap
        temp = *current;
        *current = *swap_pos;
        *swap_pos = temp;
        
        swap_pos++;
    }
}

int main() {
    int digits[N] = {1,2,3,4,5,6,7,8,9};
    generate_permutations(digits, 0, N-1);
    return 0;
}