/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/29 11:19:20 by jia-lim           #+#    #+#             */
/*   Updated: 2025/03/30 21:16:55 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include "rush01.c"
#include "check_unique.h"
#include "solve.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/*
	if there is a space at the end, it will ignore
	if there is multiple consecutive space, it will just skip
*/
int	get_question(char *str, int *arr, int *size)
{
	int	consecutive_space;
	int	charcount;

	charcount = 0;
	consecutive_space = 0;
	while (*str != '\0')
	{
		charcount++;
		if (*str >= '1' && *str <= '4')
		{
			arr[*size] = *str - '0';
			str++;
			(*size)++;
			consecutive_space = 0;
		}
		else if (*str == ' ' && consecutive_space == 0)
		{
			consecutive_space = 1;
			str++;
		}
		else
			break ;
	}
	return (charcount);
}

void	print_result(int result[4][4])
{
	char	c;
	int		x;
	int		y;

	x = 0;
	y = 0;
	while (y < 4)
	{
		while (x < 4)
		{
			c = result[y][x] + '0';
			write(1, &c, 1);
			if (x < 3)
				write(1, " ", 1);
			x++;
		}
		write(1, "\n", 1);
		x = 0;
		y++;
	}
}

int		solve(int nth, int arr[4][4], int cond[16]);

int	get_size(char *input_str)
{
	int	size;
	int	sqrt;
	int	largest_num;

	size = 0;
	largest_num = 0;
	sqrt = 1;
	while (*input_str != '\0')
	{
		if (*input_str >= '1' && *input_str <= '9')
		{
			size++;
			if (*input_str - '0' > largest_num)
				largest_num = *input_str - '0';
		}
		input_str++;
	}
	while (sqrt * sqrt <= size)
	{
		sqrt++;
	}
	if (((sqrt - 1) * (sqrt - 1) == size) && largest_num == (sqrt - 1))
		return (sqrt - 1);
	else
		return (-1);
}

int	dynamic_size_prep_arr(char *argv[1], int **result, int size)
{
	// TO DO
	return (0);
}

int	dynamic_size_cond(char *input_str, int **cond, int size)
{
	int	i;
	int	charcount;
	int	consecutive_space;

	*cond = malloc(4 * (size) * (size));
	if (*cond == NULL)
		return (-1);
	i = 0;
	charcount = 0;
	while (*input_str != '\0')
	{
		charcount++;
		if (*input_str >= '1' && *input_str - '0' <= size)
		{
			(*cond)[i] = *input_str - '0';
			input_str++;
			i++;
			consecutive_space = 0;
		}
		else if (*input_str == ' ' && consecutive_space == 0)
		{
			consecutive_space = 1;
			input_str++;
		}
		else
			break ;
	}
	return (charcount);
}

void	dynamic_size_arr(int	***arr, int	size)
{
	int	i;
	int	j;

	*arr = malloc(4 * size);
	if (*arr == NULL)
		return;
	i = 0;
	while (i < size)
	{
		j = 0;
		(*arr)[i] = malloc(4 * size);
		if (*arr == NULL)
			return;
		while (j < size)
		{
			(*arr)[i][j] = 0;
			j++;
		}
		i++;
	}
}

// int	main(int argc, char *argv[])
int main()
{
	int argc = 2;
	char	*argv[] = {"test", "4 3 2 1 1 2 2 2 4 3 2 1 1 2 2 2"};
	
	int	size;
	int	*cond;
	int	**result;
	int	charcount;
	int	free_count;

	size = get_size(argv[1]); // gets size, ensure all correct numbers
	if (argc != 2 || size == -1)
	{
		write(1, "Error\n", 6);
		return (0);
	}
	charcount = dynamic_size_cond(argv[1], &cond, size);
	if (charcount != ((size * size) * 2) - 1)
	{
		write(1, "Error\n", 6);
		return (0);
	}
	dynamic_size_arr(&result, size);

	if (solve(0, result, cond, size) == 1)
	{
		print_result(result);
	}
	else
	{
		write(1, "Error\n", 6);
	}
	return (0);
}
// argc = 2;
// argv = {"", "4 3 2 1 1 2 2 2 4 3 2 1 1 2 2 2"};
