/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/10 17:12:26 by rchiam            #+#    #+#             */
/*   Updated: 2025/04/10 22:40:35 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_is_sep(char c, char *charset)
{
	int	i;

	i = 0;
	while (charset[i])
	{
		if (c == charset[i])
			return (1);
		i++;
	}
	return (0);
}

int	get_wordcount(char *str, char *charset)
{
	int	count;

	count = 0;
	while (*str)
	{
		while (*str && ft_is_sep(*str, charset))
			str++;
		if (*str)
		{
			count++;
			while ((*str && !ft_is_sep(*str, charset)))
				str++;
		}
	}
	return (count);
}

char	*ft_strcpy(char *dest, char *src)
{
	char	*start;

	start = dest;
	while (*src)
	{
		*dest = *src;
		dest++;
		src++;
	}
	*dest = '\0';
	return (start);
}

char	*ft_strdup(char *start, char *end)
{
	int		len;
	char	*str;
	char	*output;

	len = end - start;
	str = (char *)malloc(sizeof(char) * len + 1);
	if (str == NULL)
		return (NULL);
	output = str;
	while (start < end)
	{
		*str = *start;
		start++;
		str++;
	}
	str = 0;
	return (output);
}

char	**ft_split(char *str, char *charset)
{
	int		i;
	int		j;
	char	**output;
	char	**output_start;
	int		words;

	words = get_wordcount(str, charset);
	i = 0;
	j = 0;
	output = (char **)malloc(sizeof(char *) * (words + 1));
	output_start = output;
	while (str[i])
	{
		j = i;
		if (!ft_is_sep(str[j], charset))
			j++;
		else
		{
			*output = ft_strdup(&str[i], &str[i + j]);
			output++;
			i = j;
			j = i;
		}
	}
	return (output);
}

#include <unistd.h>

void	ft_putstr(char *str)
{
	while (*str)
	{
		write(1, str, 1);
		str++;
	}
}

void	print_split_result(char **str_arr)
{
	while (str_arr)
	{
		ft_putstr(*str_arr);
		str_arr++;
	}
}

int	main(void)
{
	char *str1;
	char *charset1;
	char **result1;
	char *str2;
	char *charset2;
	char **result2;
	char *str3;
	char *charset3;
	char **result3;
	char *str4;
	char *charset4;
	char **result4;
	char *str5;
	char *charset5;
	char **result5;
	char *str6;
	char *charset6;
	char **result6;
	char *str7;
	char *charset7;
	char **result7;

	str1 = "hello world";
	charset1 = " ";
	result1 = ft_split(str1, charset1);
	print_split_result(result1);
	str2 = "   split   this   string   ";
	charset2 = " ";
	result2 = ft_split(str2, charset2);
	print_split_result(result2);
	str3 = "abc";
	charset3 = "";
	result3 = ft_split(str3, charset3);
	print_split_result(result3);
	str4 = "";
	charset4 = " ";
	result4 = ft_split(str4, charset4);
	print_split_result(result4);
	str5 = ",,multiple,,separators,,";
	charset5 = ",";
	result5 = ft_split(str5, charset5);
	print_split_result(result5);
	str6 = "one two three";
	charset6 = " o";
	result6 = ft_split(str6, charset6);
	print_split_result(result6);
	str7 = NULL;
	charset7 = " ";
	result7 = ft_split(str7, charset7);
	print_split_result(result7);
	return (0);
}