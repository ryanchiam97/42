/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_params.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/01 22:20:27 by rchiam            #+#    #+#             */
/*   Updated: 2025/04/02 20:30:17 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	putstr(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		write(1, &str[i], 1);
		i++;
	}
	write(1, "\n", 1);
}

void	swap(char **s1, char **s2)
{
	char	*temp;

	temp = *s1;
	*s1 = *s2;
	*s2 = temp;
}

int	compare(int i, char **argv)
{
	int	update;
	int	j;

	while (i > 2)
	{
		update = 0;
		j = 0;
		while (argv[i][j] < argv[i - 1][j])
		{
			update = 1;
			swap(&argv[i], &argv[i - 1]);
			j++;
		}
		i--;
	}
	return (update);
}

int	main(int argc, char **argv)
{
	int		i;
	int		update;

	if (argc <= 1)
		return (0);
	update = 1;
	while (update == 1)
	{
		update = compare(argc - 1, argv);
	}
	i = 1;
	while (i < argc)
	{
		putstr(argv[i]);
		i++;
	}
	return (0);
}
