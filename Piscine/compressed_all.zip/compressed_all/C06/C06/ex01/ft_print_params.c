/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_params.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/01 21:12:49 by rchiam            #+#    #+#             */
/*   Updated: 2025/04/02 19:49:04 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	main(int argc, char **argv)
{
	int		num;
	int		i;
	char	*str;
	int		j;

	num = argc - 1;
	i = 1;
	str = "";
	while (argv[i])
	{
		str = argv[i];
		j = 0;
		while (str[j])
		{
			write(1, &str[j], 1);
			j++;
		}
		write(1, "\n", 1);
		i++;
	}
	return (0);
}
