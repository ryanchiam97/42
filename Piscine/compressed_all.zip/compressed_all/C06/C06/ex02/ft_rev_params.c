/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_params.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/01 21:28:35 by rchiam            #+#    #+#             */
/*   Updated: 2025/04/02 19:49:22 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	main(int argc, char **argv)
{
	int		i;
	char	*str;

	i = 0;
	while (argc - 1 - i > 0)
	{
		str = argv[argc - 1 - i];
		while (*str)
		{
			write(1, str, 1);
			str++;
		}
		i++;
		write(1, "\n", 1);
	}
	return (0);
}
