/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_program_name.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/01 21:04:47 by rchiam            #+#    #+#             */
/*   Updated: 2025/04/02 20:52:41 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	main(int argc, char **argv)
{
	char	*str;

	if (argc > 1)
		return (0);
	str = argv[0];
	while (*str)
	{
		write(1, str, 1);
		str ++;
	}
	write(1, "\n", 1);
	return (0);
}
