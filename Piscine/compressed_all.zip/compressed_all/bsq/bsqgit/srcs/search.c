/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   search.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: chikoh <chikoh@student.42singapore.sg>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/08 18:26:01 by chikoh            #+#    #+#             */
/*   Updated: 2025/04/08 18:36:53 by chikoh           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

#include "ft.h"

void	print_map(char **table, t_file_info *info, t_box_info *box_info)
{
	int	row;
	int	col;

	row = 0;
	while (row < info->line_no)
	{
		col = 0;
		while (col < info->line_len)
		{
			if ((row >= box_info->cord.y_cord
					&& row < (box_info->cord.y_cord + box_info->len))
				&& (col >= box_info->cord.x_cord
					&& col < (box_info->cord.x_cord + box_info->len)))
				write(1, &info->full_char, 1);
			else
				write(1, &table[row + 1][col], 1);
			col++;
		}
		write(1, "\n", 1);
		row++;
	}
}

int	check_obstruction(char **table, t_cord cord, t_file_info *info, int box_len)
{
	t_cord	seek_cord;

	seek_cord.x_cord = cord.x_cord;
	if ((cord.y_cord + box_len) > info->line_no
		|| (cord.x_cord + box_len) > info->line_len)
		return (0);
	while (seek_cord.x_cord < (cord.x_cord + box_len))
	{
		seek_cord.y_cord = cord.y_cord;
		while (seek_cord.y_cord < (cord.y_cord + box_len))
		{
			if (table[seek_cord.y_cord + 1][seek_cord.x_cord]
				== info->obstacle_char)
				return (0);
			seek_cord.y_cord++;
		}
		seek_cord.x_cord++;
	}
	return (1);
}

void	search_grid_str(char **table, t_file_info *info)
{
	t_box_info	largest_box;
	t_cord		cord;
	int			box_len;

	set_largest_box(&largest_box, -1, 0, 0);
	box_len = 1;
	cord.y_cord = 0;
	while ((cord.y_cord + box_len - 1) <= info->line_no)
	{
		cord.x_cord = 0;
		while ((cord.x_cord + box_len) <= info->line_len)
		{
			if (check_obstruction(table, cord, info, box_len))
			{
				set_largest_box(&largest_box, box_len,
					cord.x_cord, cord.y_cord);
				box_len++;
			}
			else
				cord.x_cord++;
		}
		cord.y_cord++;
	}
	print_map(table, info, &largest_box);
	clean_table(table);
}

void	set_largest_box(t_box_info *box_info, int len, int x_cord, int y_cord)
{
	box_info->len = len;
	box_info->cord.x_cord = x_cord;
	box_info->cord.y_cord = y_cord;
}
