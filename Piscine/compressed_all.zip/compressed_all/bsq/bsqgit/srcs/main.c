/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: chikoh <chikoh@student.42singapore.sg>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/07 12:34:47 by chikoh            #+#    #+#             */
/*   Updated: 2025/04/08 22:33:54 by chikoh           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

#include "ft.h"

void	process_stdin(void)
{
	char				*file_str;
	char				*filename;
	t_file_info			info;
	t_validate_flags	flags;

	flags.length = -1;
	flags.box_exist = 0;
	filename = read_stdin();
	file_str = read_file(filename);
	if (file_str != 0 && validate_str(file_str, &info, &flags))
		search_grid_str(ft_split(file_str, "\n"), &info);
	else
		write(1, "map error\n", 10);
	free(filename);
	free(file_str);
}

void	process_files(int argc, char **argv)
{
	int					i;
	char				*file_str;
	t_file_info			info;
	t_validate_flags	flags;

	i = 1;
	while (i < argc)
	{
		flags.length = -1;
		flags.box_exist = 0;
		file_str = read_file(argv[i]);
		if (file_str != 0 && validate_str(file_str, &info, &flags))
			search_grid_str(ft_split(file_str, "\n"), &info);
		else
			write(1, "map error\n", 10);
		free(file_str);
		i++;
	}
}

int	main(int argc, char **argv)
{
	if (argc == 1)
		process_stdin();
	else
		process_files(argc, argv);
	return (0);
}
