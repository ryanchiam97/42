/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   read_file.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: chikoh <chikoh@student.42singapore.sg>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/08 18:28:25 by chikoh            #+#    #+#             */
/*   Updated: 2025/04/08 22:31:03 by chikoh           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

#include "ft.h"

char	*read_stdin(void)
{
	char	*str;
	char	buffer[100];
	int		read_size;
	int		i;

	read_size = read(0, buffer, 100);
	str = (char *)malloc(sizeof(char) * 1);
	*str = 0;
	while (read_size > 0)
	{
		str = ft_strncat(str, buffer, read_size);
		i = 0;
		while (read_size > 0)
		{
			if (str[i] == '\n')
			{
				str[i] = 0;
				return (str);
			}
			read_size--;
			i++;
		}
		read_size = read(0, buffer, 100);
	}
	return (str);
}

char	*read_file(char *filename)
{
	char	*str;
	char	buffer[100];
	int		file_desc;
	int		read_size;

	file_desc = 0;
	if (filename != 0)
		file_desc = open(filename, O_RDONLY);
	if (file_desc == -1)
		return (0);
	read_size = read(file_desc, buffer, 100);
	if (read_size == -1)
		return (0);
	str = (char *)malloc(sizeof(char) * 1);
	*str = 0;
	str = ft_strncat(str, buffer, read_size);
	while (read_size > 0)
	{
		read_size = read(file_desc, buffer, 100);
		str = ft_strncat(str, buffer, read_size);
	}
	if (file_desc != 0)
		close(file_desc);
	return (str);
}

void	clean_table(char **table)
{
	char	**start_table;

	start_table = table;
	while (*table)
	{
		free(*table);
		table++;
	}
	free(start_table);
}

int	ft_atoi(char *str)
{
	int	number;

	number = 0;
	while (*str >= '0' && *str <= '9')
	{
		number = number * 10 + *str - '0';
		str++;
	}
	return (number);
}
