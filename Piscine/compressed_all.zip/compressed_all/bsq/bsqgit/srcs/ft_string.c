/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_string.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: chikoh <chikoh@student.42singapore.sg>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/08 17:13:04 by chikoh            #+#    #+#             */
/*   Updated: 2025/04/08 18:25:31 by chikoh           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

#include "ft.h"

int	ft_count_substring(char *str, char *sep)
{
	int	count;

	count = 1;
	while (*str)
	{
		if (*str == *sep)
			count++;
		str++;
	}
	return (count);
}

int	ft_strlen(char *str)
{
	int	count;

	count = 0;
	while (*str)
	{
		str++;
		count++;
	}
	return (count);
}

char	*ft_strncat(char *dest, char *src, int size)
{
	char	*buffer;
	int		length;
	int		seek;

	length = ft_strlen(dest);
	buffer = (char *)malloc(sizeof(char) * (length + size + 1));
	seek = 0;
	while (seek < length)
	{
		buffer[seek] = dest[seek];
		seek++;
	}
	free(dest);
	while (seek < (length + size))
	{
		buffer[seek] = src[seek - length];
		seek++;
	}
	buffer[seek] = 0;
	return (buffer);
}

char	*ft_strdup(char *start, char *end)
{
	char	*string;
	char	*string_start;

	string = (char *)malloc(sizeof(char) * (end - start + 1));
	string_start = string;
	while (start < end)
	{
		*string = *start;
		start++;
		string++;
	}
	*string = 0;
	return (string_start);
}

char	**ft_split(char *str, char *sep)
{
	char	*start;
	char	*end;
	char	**table;
	char	**table_start;

	table = (char **)malloc(sizeof(char *)
			* (ft_count_substring(str, sep) + 1));
	table_start = table;
	start = str;
	end = start;
	while (*str)
	{
		if (*end != *sep)
			end++;
		else
		{
			*table = ft_strdup(start, end);
			start = end + 1;
			end = start;
			table++;
		}
		str = end;
	}
	*table = 0;
	return (table_start);
}
