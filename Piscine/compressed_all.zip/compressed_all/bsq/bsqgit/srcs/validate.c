/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   validate.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: chikoh <chikoh@student.42singapore.sg>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/08 17:11:04 by chikoh            #+#    #+#             */
/*   Updated: 2025/04/08 20:12:17 by chikoh           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

int	validate_first_row(char *first_row)
{
	int	i;
	int	digit_detected;

	digit_detected = 0;
	while (*first_row >= '0' && *first_row <= '9')
	{
		digit_detected = 1;
		first_row++;
	}
	i = 0;
	while (*first_row >= ' ' && *first_row <= 126 && i < 3)
	{
		i++;
		first_row++;
	}
	return (*first_row == 0 && digit_detected && i == 3);
}

int	validate_subsequent_rows(char **str, int row,
		t_file_info *info, t_validate_flags *flags)
{
	int		i;

	if (flags->length == -1)
		flags->length = ft_strlen(str[row]);
	else if (flags->length != ft_strlen(str[row]))
		return (0);
	i = 0;
	while (str[row][i])
	{
		flags->box_exist = flags->box_exist || str[row][i] == info->empty_char;
		if (str[row][i] != info->empty_char
			&& str[row][i] != info->obstacle_char)
			return (0);
		i++;
	}
	if (row == (info->line_no - 1))
	{
		info->line_len = flags->length;
		return (flags->box_exist);
	}
	else
		return (1);
}

int	validate_str(char *str, t_file_info *info, t_validate_flags *flags)
{
	int		row_no;
	char	**lines;

	lines = ft_split(str, "\n");
	row_no = 0;
	while (lines[row_no])
	{
		if (row_no == 0)
		{
			if (!validate_first_row(lines[row_no]))
				break ;
			info->line_no = ft_atoi(lines[row_no]);
			info->empty_char = lines[row_no][ft_strlen(lines[row_no]) - 3];
			info->obstacle_char = lines[row_no][ft_strlen(lines[row_no]) - 2];
			info->full_char = lines[row_no][ft_strlen(lines[row_no]) - 1];
		}
		else
			if (!validate_subsequent_rows(lines, row_no, info, flags))
				break ;
		row_no++;
	}
	clean_table(lines);
	return ((row_no - 1) == info->line_no);
}
