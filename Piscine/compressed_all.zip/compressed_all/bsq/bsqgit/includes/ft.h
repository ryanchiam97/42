/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft.h                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: chikoh <chikoh@student.42singapore.sg>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/08 17:15:29 by chikoh            #+#    #+#             */
/*   Updated: 2025/04/08 22:14:28 by chikoh           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_H
# define FT_H

typedef struct s_cord
{
	int	x_cord;
	int	y_cord;
}	t_cord;

typedef struct s_box_info
{
	int		len;
	t_cord	cord;
}	t_box_info;

typedef struct s_file_info
{
	int		line_no;
	int		line_len;
	char	empty_char;
	char	obstacle_char;
	char	full_char;
}	t_file_info;

typedef struct s_valildate_flags
{
	int	box_exist;
	int	length;
}	t_validate_flags;

char	*read_file(char *filename);
void	clean_table(char **table);
int		ft_count_substring(char *str, char *sep);
int		ft_atoi(char *str);
void	set_largest_box(t_box_info *box_info, int len, int x_cord, int y_cord);
void	print_map(char **table, t_file_info *info, t_box_info *box_info);
int		check_obstruction(char **table, t_cord cord,
			t_file_info *info, int box_len);
void	search_grid_str(char **table, t_file_info *info);
void	process_stdin(void);
void	process_files(int argc, char **argv);
int		ft_strlen(char *str);
char	*ft_strncat(char *dest, char *src, int size);
char	*ft_strdup(char *start, char *end);
char	**ft_split(char *str, char *sep);
int		validate_first_row(char *first_row);
int		validate_subsequent_rows(char **str, int row_number,
			t_file_info *info, t_validate_flags *flags);
int		validate_str(char *str, t_file_info *info, t_validate_flags *flags);
char	*read_stdin(void);
#endif
