#!/bin/bash
git log --decorate=short --pretty="%H"


