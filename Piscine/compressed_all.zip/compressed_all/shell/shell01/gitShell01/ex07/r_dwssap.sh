output=$(cat etc/passwd | grep -v "^#" | )
echo="$output"
