#!/bin/bash
odd=$(ls -l | awk 'NR % 2 == 1')
echo "$odd"
