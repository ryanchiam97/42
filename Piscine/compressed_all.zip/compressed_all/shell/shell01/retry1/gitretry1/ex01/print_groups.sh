#!/bin/bash
echo $(id -Gn | tr ' ' ',' | tr -d '\n')
