/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   group_handler.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/06 13:57:48 by rchiam            #+#    #+#             */
/*   Updated: 2025/04/06 18:15:52 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while(str[i]!='\0')
		i++;
	return i;
}

int	calc_sets(int len)
{
	int	sets;

	sets = len / 3;
	if (len % 3 != 0)
		sets += 1;
	return (sets);
}

int	*create_groups(char *str, int *num_groups)
{
	int		remainder;
	int		sets;
	int		i;
	int		j;
	char 	*temp;
	int		len;

	len = ft_strlen(str);
	sets = calc_sets(len);
	num_groups = (int *)malloc(sets * sizeof(int));
	if (!num_groups)
		return (NULL);
	num_groups[sets] = '\0';
	i = len-1;
	j = sets - 1;
	temp = malloc(1 * sizeof(int));
	while(i >= 0)
	{
		num_groups[j] += str[i]-'0';
		int a = num_groups[j];
		if (i - 1 >= 0)
			num_groups[j] += (str[i-1] - '0') * 10;
			int b = num_groups[j];
		if (i - 2 >= 0)
			num_groups[j] += (str[i-2] - '0') * 100;
			int c = num_groups[j];
		int d = num_groups[j];
		i-=3;
		j--;
	}
	free(temp);
	return (num_groups);
}
// #include <stdio.h>
// int main(void)
// {
// 	char *str = "1234567890";
// 	int	*num_groups;
// 	int	len;
// 	int	size;

// 	len = ft_strlen(str);
// 	num_groups = create_groups(str, num_groups, len);
// 	size = len / 3;
// 	if (len % 3 != 0)
// 		size++;

// 	int i = 0;
// 	while (i < 4)
// 	{
// 		printf("%i\n", num_groups[i]);
// 		i ++;
// 	}
// 	free(num_groups);
// 	return (0);
// }