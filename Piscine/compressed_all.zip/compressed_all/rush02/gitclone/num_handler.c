/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   num_handler.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/05 18:13:11 by rchiam            #+#    #+#             */
/*   Updated: 2025/04/06 18:22:16 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "hundreds_handler.c"
#include "group_handler.c"

#include <unistd.h>

char	*thousands[13] = {"", "thousand", "million", "billion", "trillion", "quadrillion", "quintillion", "sextillion", "septillion", "octillion", "nonillion", "decillion", "undecillion"};
#include <string.h>
// Fake dictionary data
typedef struct s_dict_entry
{
    char    *key;
    char    *value;
}               t_dict_entry;
typedef struct s_dict_entry t_dict_entry;
t_dict_entry fake_dict[] = {
    {"0", "zero"},
    {"1", "one"},
    {"2", "two"},
    {"3", "three"},
    {"4", "four"},
    {"5", "five"},
    {"6", "six"},
    {"7", "seven"},
    {"8", "eight"},
    {"9", "nine"},
    {"10", "ten"},
    {"11", "eleven"},
    {"12", "twelve"},
    {"13", "thirteen"},
    {"14", "fourteen"},
    {"15", "fifteen"},
    {"16", "sixteen"},
    {"17", "seventeen"},
    {"18", "eighteen"},
    {"19", "nineteen"},
    {"20", "twenty"},
    {"30", "thirty"},
    {"40", "forty"},
    {"50", "fifty"},
    {"60", "sixty"},
    {"70", "seventy"},
    {"80", "eighty"},
    {"90", "ninety"},
    {"100", "hundred"},
    {"1000", "thousand"},
    {"1000000", "million"},
    {"1000000000", "billion"},
    {"1000000000000", "trillion"},
	{"1000000000000000", "quadrillion"},
	{"1000000000000000000", "quintillion"},
	{"1000000000000000000000", "sextillion"},
	{"1000000000000000000000000", "septillion"},
	{"1000000000000000000000000000", "octillion"},
	{"1000000000000000000000000000000", "nonillion"},
	{"1000000000000000000000000000000000", "decillion"},
	{"1000000000000000000000000000000000000", "undecillion"},
    {NULL, NULL} // Null terminator for the array
};
char    *lookup(t_dict_entry *dict, char *key)
{
    int i = 0;
    while (dict[i].key != NULL)
    {
        if (strcmp(dict[i].key, key) == 0)
        {
            return (dict[i].value);
        }
        i++;
    }
    return (NULL);
}


void	ft_putstr(char *str)
{
	int	i;

	i = 0;
	while(str[i])
	{
		write(1, &str[i], 1);
		i++;
	}
}

void	fill_zeroes(char *str, int start_index, int num_zeroes)
{
	int	i;

	i = 0;
	while (i < num_zeroes)
	{
		str[start_index + i] = '0';
		i++;
	}
	str[start_index + num_zeroes] = '\0';
}

void	ft_num_handler(int	*int_arr, int size)
{
	int		i;
	char	*word;
	int		thousands;
	char	*thousands_str;
	int		num_zeroes;
	char	*result;

	i = 0;
	while (i < size)
	{
		word = ft_hundreds_handler(int_arr[i]);
		if (word)
		{
			ft_putstr(word);
			if (size - 1- i > 0 && int_arr[i] != 0)
			{
				thousands = size - 1 - i;
				num_zeroes = thousands * 3;
				thousands_str = (char *)malloc(2 + num_zeroes);
				if (thousands_str == NULL)
				{
					free(word);
					return;
				}
				thousands_str[0] = '1';
				fill_zeroes(thousands_str, 1, num_zeroes);
				result = lookup(fake_dict, thousands_str);
				if (result)
				{
					ft_putstr(" ");
					ft_putstr(result);
					ft_putstr(" ");
				}
				free(thousands_str);
			}
			free(word);
		}
		i++;
	}
	ft_putstr("\n");
}

///////////////////////////////////////////////////////////////////////////

// i = 0
// while (i < total_sets)
	// word = ft_hundreds_handler(int_arr[i])
	// if (word)
		// print word
		// if (total_sets - i != 0)
			// int power = 1000 ^ (total_sets -1 - i)
			// putnbr(power)
			// print lookup(dict, dict_size, int_arr[power])
	// i++

	// Placeholder for the lookup function since we don't have the dictionary loading mechanism

int main(int argc, char **argv)
{
	char	*num_str;
	int		len;
	int		*num_groups;
	int		num_sets;

	if (argc != 2)
	{
		ft_putstr("Error\n");
		return (1);
	}
	num_str = argv[1];
	len = ft_strlen(num_str);
	num_groups = NULL;
	if (len == 0)
	{
		ft_putstr("zero\n");
		return (0);
	}
	num_sets = calc_sets(len);
	num_groups = create_groups(num_str, num_groups);
	if (!num_groups)
	{
		ft_putstr("Error\n");
		return (1);
	}
	ft_num_handler(num_groups, num_sets);
	free(num_groups);
	return (0);
	// // Example usage:
    // int num1 = 123456789;
    // int num2 = 987654321;
    // int num3 = 100;
    // int num4 = 5;
    // int num5 = 123;
    // int num6 = 1000;
    // int num7 = 1000000;

    // // Split numbers into groups of three (hundreds)
    // int arr1[] = {123, 456, 789}; // Represents 123,456,789
    // int size1 = sizeof(arr1) / sizeof(arr1[0]);

    // int arr2[] = {987, 654, 321}; // Represents 987,654,321
    // int size2 = sizeof(arr2) / sizeof(arr2[0]);

    // int arr3[] = {100};
    // int size3 = sizeof(arr3) / sizeof(arr3[0]);

    // int arr4[] = {5};
    // int size4 = sizeof(arr4) / sizeof(arr4[0]);

    // int arr5[] = {123};
    // int size5 = sizeof(arr5) / sizeof(arr5[0]);

    // int arr6[] = {1, 0}; // Represents 1,000
    // int size6 = sizeof(arr6) / sizeof(arr6[0]);

    // int arr7[] = {1, 0, 0}; // Represents 1,000,000
    // int size7 = sizeof(arr7) / sizeof(arr7[0]);

	// int arr8[] = {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}; // Represents 1,000,000,000,000,000,000,000,000,000,000,000,000
    // int size8 = sizeof(arr8) / sizeof(arr7[8]);


    // ft_num_handler(arr1, size1);
	// printf("\ncheck:  123,456,789\n");
    // printf("\n");

    // ft_num_handler(arr2, size2);
	// printf("check  987,654,321\n");
    // printf("\n");

    // ft_num_handler(arr3, size3);
	// printf("check  100\n");
    // printf("\n");

    // ft_num_handler(arr4, size4);
	// printf("check  5\n");
    // printf("\n");

    // ft_num_handler(arr5, size5);
	// printf("check 123\n");
    // printf("\n");

    // ft_num_handler(arr6, size6);
	// printf("check 1000\n");
    // printf("\n");

    // ft_num_handler(arr7, size7);
	// printf("check  1000000\n");
    // printf("\n");

    // ft_num_handler(arr8, size8);
	// printf("check  1000000000000000000000000000000000000\n");
    // printf("\n");

    // return (0);
}