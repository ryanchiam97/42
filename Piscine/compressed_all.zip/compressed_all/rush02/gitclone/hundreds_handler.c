/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hundreds_handler.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/05 15:19:39 by rchiam            #+#    #+#             */
/*   Updated: 2025/04/06 16:46:02 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

char	*ones_to_teens[] = {"", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"};
char	*tens[] = {"", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"};

char	*ft_strcat(char *dest, char	*src)
{
	int	i;
	int	src_count;

	i = 0;
	src_count = 0;
	while (dest[i])
	{
		i ++;
	}
	while (src[src_count])
	{
		dest[i + src_count] = src[src_count];
		src_count ++;
	}
	dest[i + src_count] = '\0';
	return (dest);
}

char	*ft_strdup(char *str)
{
	char	*dup;
	int		i;

	i = 0;
	dup = NULL;
	if (!str)
		return (0);
	while (str[i] != '\0')
	{
		i++;
	}
	dup = malloc(i * sizeof(char) + 1);
	if (!dup)
		return (0);
	i = 0;
	while (str[i])
	{
		dup[i] = str[i];
		i++;
	}
	dup[i] = '\0';
	return (dup);
}

char	*ft_tens(int num, char *output)
{
	char	*temp_output;
	char	*ones_str;

	temp_output = ft_strdup(output);
	if (num < 20)
	{
		free(temp_output);
		return (ft_strdup(ones_to_teens[num]));// dict[num]-> value // lookup(dict, dict_size, putnbr(num))
	}
	else if (num < 100)
	{
		ft_strcat(temp_output, tens[(num / 10)]);// dict[num/10]-> value // lookup(dict, dict_size, putnbr(num / 10))
		if (num % 10 != 0)
		{
			ones_str = ft_strdup(ones_to_teens[num % 10]);// dict[num%10]-> value // lookup(dict, dict_size, putnbr(num % 10))
			ft_strcat(temp_output, " ");
			ft_strcat(temp_output, ones_str);
			free(ones_str);
		}
		return (temp_output);
	}
	free(temp_output);
	return (0);
}

char	*ft_hundreds_handler(int num)
{
	char	*temp_output;
	char	*tens_str;
	char	*final_output;

	temp_output = ft_strdup("");
	if (num == 0)
		return (ft_strdup(ones_to_teens[0]));// lookup(dict, dict_size, putnbr(num)
	else if (num < 100)
		return (ft_tens(num, temp_output));
	else if (num >= 100)
	{
		ft_strcat(temp_output, ft_strdup(ones_to_teens[num / 100]));// lookup(dict, dict_size, putnbr(num / 100))
		ft_strcat(temp_output, " hundred"); // lookup(dict, dict_size, 100)
		if (num % 100 != 0)
		{
			tens_str = ft_tens(num % 100, ft_strdup("")); 
			if (tens_str[0] != '\0')
				ft_strcat(ft_strcat(temp_output, " "), tens_str);
			free(tens_str);
		}
		final_output = ft_strdup(temp_output);
		free(temp_output);
		return (final_output);
	}
	return (0);
}
/////////////////////////////////////////////////////////////////////////
// void test_number(int num) 
// {
//     char *output = ft_hundreds_handler(num);
//     printf("%d: %s\n", num, output);
//     free(output);
// }

// int main() {
//     printf("--- Simple Tests ---\n");
//     test_number(0);
//     test_number(5);
//     test_number(12);
//     test_number(20);
//     test_number(35);
//     test_number(99);
//     test_number(100);
//     test_number(101);
//     test_number(115);
//     test_number(250);
//     test_number(999);
//     return (0);
// }