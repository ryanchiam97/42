/* 
Assignment name  : alpha_mirror
Expected files   : alpha_mirror.c
Allowed functions: write
--------------------------------------------------------------------------------
Write a program called alpha_mirror that takes a string and displays this string
after replacing each alphabetical character by the opposite alphabetical
character, followed by a newline.
'a' becomes 'z', 'Z' becomes 'A'
'd' becomes 'w', 'M' becomes 'N'
and so on.

Case is not changed.
If the number of arguments is not 1, display only a newline.

Examples:

$>./alpha_mirror "abc"
zyx
$>./alpha_mirror "My horse is Amazing." | cat -e
Nb slihv rh Znzarmt.$
$>./alpha_mirror | cat -e
$
$>
*/
#include <unistd.h>
int main(int argc, char **argv)
{
	if(argc == 2)
	{
		//65-90 upper A-Z
		//97-122 lower a-z
		char *str = argv[1];
		int i = 0;
		char c;
		int n;
		while(str[i])
		{
			if (str[i] >= 65 && str[i] <= 90)
			{
				if (str[i] <= 78)
					c = 'Z' - (str[i]-'A');
				else
					c = 'A' - (str[i] - 'Z');
				write(1, &c, 1);
			}
			else if (str[i] >= 97 && str[i] <= 122)
			{
				if (str[i] <= 110)
					c = 'z' - (str[i]-'a');
				else
					c = 'a' - (str[i] - 'z');
				write(1, &c, 1);
			}
			else
			{
				write(1, &str[i], 1);
			}
			i++;
		}
	}
	write(1,"\n",1);
}
