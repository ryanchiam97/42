/* 
Assignment name  : ft_strrev
Expected files   : ft_strrev.c
Allowed functions:
--------------------------------------------------------------------------------
Write a function that reverses (in-place) a string.
It must return its parameter.
Your function must be declared as follows:
char    *ft_strrev(char *str);
*/

char *ft_strrev(char *str)
{
	int i = 0;
	while (str[i])
		i++;
	int size = i;
	i = 0;
	char tmp;
	while (i <= size/2)
	{
		tmp = str[i];
		str[i] = str[size - 1 - i];
		str[size - 1 - i] = tmp;
		i++;
	}
	return str;
}
#include <stdio.h>
int main(int c, char **v)
{
	printf("%s",ft_strrev(v[1]));
	return 0;
}