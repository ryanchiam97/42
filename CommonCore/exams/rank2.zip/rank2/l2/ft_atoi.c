/* 
Assignment name  : ft_atoi
Expected files   : ft_atoi.c
Allowed functions: None
--------------------------------------------------------------------------------

Write a function that converts the string argument str to an integer (type int)
and returns it.

It works much like the standard atoi(const char *str) function, see the man.

Your function must be declared as follows:

int	ft_atoi(const char *str);
 */

 int ft_atoi(const char *str)
 {
	int sign = 0;
	int result = 0;
	while (*str == ' ')
		str++;
	if (*str == '-')
	{
		sign = -1;
		str++;
	}
	else if (*str == '+' || (*str >= 0) && (*str <= 9))
		sign = 1;
	if (*str == '+')
		str++;
	while(*str)
	{
		result *= 10;
		result += (*str - '0');
		str++;
	}
	return sign * result;
 }
#include <stdio.h>
 int main(int argc, char** argv)
 {
	printf("%i\n",ft_atoi(argv[1]));
 }