/* 
Assignment name  : ft_atoi_base
Expected files   : ft_atoi_base.c
Allowed functions: None
--------------------------------------------------------------------------------
Write a function that converts the string argument str (base N <= 16)
to an integer (base 10) and returns it.
The characters recognized in the input are: 0123456789abcdef
Those are, of course, to be trimmed according to the requested base. For
example, base 4 recognizes "0123" and base 16 recognizes "0123456789abcdef".
Uppercase letters must also be recognized: "12fdb3" is the same as "12FDB3".
Minus signs ('-') are interpreted only if they are the first character of the
string.
Your function must be declared as follows:
int	ft_atoi_base(const char *str, int str_base);
*/

int	ft_atoi_base(const char *str, int str_base)
{
	int i = 0;
	int n = 0;
	int sign = 1;
	while (str[i] == ' ')
		i++;
	if (str[i] == '-')
	{
		sign = -1;
		i++;
	}
	char * basechars = "0123456789abcdef";
	basechars[str_base] = '\0';
	while(str[i] && isvalid(str[i]))
	{
		n *= str_base;
		if (str[i]>='0' && str[i] <= '9')
			n += str[i] - '0';
		else if (str[i]>='A' && str[i] <= 'F')
			n += (10 + str[i] - 'A');
		else if (str[i]>='a' && str[i] <= 'f')
			n += (10 + str[i] - 'a');
		i++;
	}
	return sign * n;
}

int isvalid(char c)
{
	int i = 0;
	char *s = "0123456789abcdefABCDEF"; 
	while (s[i])
	{
		if (s[i]!=c)
			return 0;
		i++;
	}
	return 1;
}