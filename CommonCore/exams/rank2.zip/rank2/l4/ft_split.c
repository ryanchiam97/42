/* 
Assignment name  : ft_split
Expected files   : ft_split.c
Allowed functions: malloc
--------------------------------------------------------------------------------
Write a function that takes a string, splits it into words, and returns them as
a NULL-terminated array of strings.
A "word" is defined as a part of a string delimited either by spaces/tabs/new
lines, or by the start/end of the string.
Your function must be declared as follows:
char    **ft_split(char *str);
*/

int countwords(char *str)
{
	int i = 0;
	int words = 0;
	while (str[i])// while str[i]
	{
		while (str[i] == ' '||str[i] == '\t'||str[i] == '\n')// skip all spaces
			i++;
		if (str[i] == '\0')//break if  eof
			break;
		words++;//add words
		while (str[i] != ' '&& str[i] != '\t' && str[i] != '\n' && str[i]!='\0')// skip word slots
			i++;
	}
	return words;
}

void copywords(char *dest, char* str, int start, int end)
{
	int i = 0;
	while(start <= end)// while start < end copy and add \0
	{
		dest[i] = str[start];
		start++;
		i++;
	}
	dest[i] = '\0';
	return;
}

int findnextword(char *str, int *start, int *end)
{
	int i = *end;// seet i as end
	while (str[i]!='\0' && (str[i] == ' '||str[i] == '\t'||str[i] == '\n'))// while not eof and space, i++
		i++;
	*start = i;// mark start as i
	while (str[i]!='\0' && (str[i] != ' '&&str[i] != '\t'&&str[i] != '\n'))// while not eof and not space, i++
		i++;
	*end = i;// mark end as i
	return (*start < *end);// return 1 if start < end... meaning something happened
}
#include <stdlib.h>
int fillwords(char **result, char *str)
{
	int start = 0;
	int end = 0;
	int wordcount = 0;
	int i = 0;

	while(findnextword(str, &start, &end))
	{
		//malloc str in result[]
		result[wordcount] = malloc(sizeof(char*)*(end - start + 1));
		// handle fail: if cannot then set i to 0, go through i to word free result[i]. return 0.
		if (!result[wordcount])
		{
			int i = 0;
			while (i < wordcount)
			{
				free(result[i]);
				i++;
			}
			return 0;
		}
		// copy words()
		copywords(result[wordcount], str, start, end);
		//word++ for eventual null tmerinator
		wordcount++;
	}
	result[wordcount] = '\0';
	return 1;
}

char    **ft_split(char *str)
{
	int wordcount = countwords(str);
	char **result = malloc(sizeof(char *)* (wordcount + 1));
	// if failed malloc here. return null
	if (!result)
	{
		return NULL;
	}
	if (!fillwords(result, str))
	{
		free(result);
		return NULL;
	}
	// if (!fillwords)
		//free result
		//return null
	return result;
	//return result
}
