/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/21 22:12:02 by rchiam            #+#    #+#             */
/*   Updated: 2025/07/04 21:03:50 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

int	handle_read(int fd, char	*buf, int *s_int)
{
	int	bytes_read;

	bytes_read = read(fd, buf, BUFFER_SIZE);
	if (bytes_read < 0)
	{
		buf = 0;
		*s_int = 0;
		return (-1);
	}
	if (bytes_read < BUFFER_SIZE && bytes_read >= 0)
		buf[bytes_read] = 0;
	return (bytes_read);
}

char	*get_seg(int start, int end, char	*buf)
{
	char	*output;
	int		i;

	output = malloc(end - start + 1 + (buf[end] == '\n'));
	if (!output)
		return (NULL);
	i = 0;
	while (start + i < end && buf[start + i])
	{
		output[i] = buf[start + i];
		i++;
	}
	if (buf[end] == '\n')
		output[i++] = '\n';
	output[i] = 0;
	return (output);
}

int	first_read_n_checks(int fd, int *s_int, char *buffer)
{
	if (*s_int == -1)
	{
		*s_int = 0;
		if (handle_read(fd, buffer, s_int) < 0)
			return (0);
	}
	if (*s_int >= BUFFER_SIZE || !buffer[*s_int])
	{
		if (handle_read(fd, buffer, s_int) <= 0)
			return (0);
		*s_int = 0;
	}
	return (1);
}

char	*get_next_line(int fd)
{
	static t_s_struct	sstruct = {.s_int = -1};
	char				*result;
	int					end;
	int					read_something;

	read_something = first_read_n_checks(fd, &sstruct.s_int, sstruct.s_buf);
	if (read_something <= 0)
		return (0);
	result = ft_strdup("");
	end = sstruct.s_int;
	while (sstruct.s_buf[end] != '\n' && sstruct.s_buf[end] != 0)
	{
		end++;
		if (end == BUFFER_SIZE)
			read_something = iteration(&end, &sstruct, &result, fd);
	}
	if (read_something)
		result = safe_join(result, get_seg(sstruct.s_int, end, sstruct.s_buf));
	if (!result)
		return (NULL);
	sstruct.s_int = end + (sstruct.s_buf[end] == '\n');
	return (result);
}

int	iteration(int *i, t_s_struct *s_struct, char **r, int fd)
{
	int	read_something;

	*r = safe_join(*r, ft_strdup(s_struct -> s_buf + s_struct -> s_int));
	if (!*r)
		return (-1);
	read_something = handle_read(fd, (s_struct -> s_buf), &(s_struct -> s_int));
	if (read_something < 0)
		return (-1);
	if (read_something == 0)
		return (0);
	s_struct -> s_int = 0;
	*i = 0;
	return (1);
}

// #include <fcntl.h>

// int	main(void)
// {
// 	int		fd;
// 	char	*line;
// 	int		line_count;

// 	fd = open("test.txt", O_RDONLY);
// 	line_count = 0;
//     for (int i = 0; i < 9; i++)
//     {
// 		line = get_next_line(fd);
//         printf("[%d] %p %s", ++line_count, line, line);
// 		fflush(stdout);
//         free(line);
//     }
//     close(fd);
// 	return (0);
// }