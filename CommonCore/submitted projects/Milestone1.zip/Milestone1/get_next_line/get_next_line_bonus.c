/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line_bonus.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/04 21:05:54 by rchiam            #+#    #+#             */
/*   Updated: 2025/07/04 21:31:12 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line_bonus.h"

int	handle_read(int fd, char	*buf, int *s_int)
{
	int	bytes_read;

	bytes_read = read(fd, buf, BUFFER_SIZE);
	if (bytes_read < 0)
	{
		buf = 0;
		*s_int = 0;
		return (-1);
	}
	if (bytes_read < BUFFER_SIZE && bytes_read >= 0)
		buf[bytes_read] = 0;
	return (bytes_read);
}

char	*get_seg(int start, int end, char	*buf)
{
	char	*output;
	int		i;

	output = malloc(end - start + 1 + (buf[end] == '\n'));
	if (!output)
		return (NULL);
	i = 0;
	while (start + i < end && buf[start + i])
	{
		output[i] = buf[start + i];
		i++;
	}
	if (buf[end] == '\n')
		output[i++] = '\n';
	output[i] = 0;
	return (output);
}

int	first_read_n_checks(int fd, int *s_int, char *buffer)
{
	if (*s_int == -1)
	{
		*s_int = 0;
		if (handle_read(fd, buffer, s_int) < 0)
			return (0);
	}
	if (*s_int >= BUFFER_SIZE || !buffer[*s_int])
	{
		if (handle_read(fd, buffer, s_int) <= 0)
			return (0);
		*s_int = 0;
	}
	return (1);
}

char	*get_next_line(int fd)
{
	static t_s_struct	s_arr[FD_MAX] = {{.s_int = -1}};
	char				*line;
	int					end;
	int					read_something;

	read_something = first_read_n_checks(fd, &s_arr[fd].s_int, s_arr[fd].s_buf);
	if (read_something <= 0)
		return (0);
	line = ft_strdup("");
	end = s_arr[fd].s_int;
	while (s_arr[fd].s_buf[end] != '\n' && s_arr[fd].s_buf[end] != 0)
	{
		end++;
		if (end == BUFFER_SIZE)
			read_something = iteration(&end, &s_arr[fd], &line, fd);
	}
	if (read_something)
		line = safe_join(line, get_seg(s_arr[fd].s_int, end, s_arr[fd].s_buf));
	if (!line)
		return (NULL);
	s_arr[fd].s_int = end + (s_arr[fd].s_buf[end] == '\n');
	return (line);
}

int	iteration(int *i, t_s_struct *s_struct, char **r, int fd)
{
	int	read_something;

	*r = safe_join(*r, ft_strdup(s_struct -> s_buf + s_struct -> s_int));
	if (!*r)
		return (-1);
	read_something = handle_read(fd, (s_struct -> s_buf), &(s_struct -> s_int));
	if (read_something < 0)
		return (-1);
	if (read_something == 0)
		return (0);
	s_struct -> s_int = 0;
	*i = 0;
	return (1);
}

// #include <fcntl.h>

// int	main(void)
// {
// 	int		fd;
// 	char	*line;
// 	int		line_count;

// 	fd = open("test.txt", O_RDONLY);
// 	line_count = 0;
//     for (int i = 0; i < 9; i++)
//     {
// 		line = get_next_line(fd);
//         printf("[%d] %p %s", ++line_count, line, line);
// 		fflush(stdout);
//         free(line);
//     }
//     close(fd);
// 	return (0);
// }