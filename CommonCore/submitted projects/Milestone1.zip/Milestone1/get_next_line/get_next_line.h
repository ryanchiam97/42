/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.h                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/14 21:24:59 by rchiam            #+#    #+#             */
/*   Updated: 2025/07/04 21:03:50 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef GET_NEXT_LINE_H
# define GET_NEXT_LINE_H
# include <unistd.h>
# include <stdio.h>
# include <stdlib.h>
# ifndef BUFFER_SIZE
#  define BUFFER_SIZE 1024
# endif
# ifndef FD_MAX
#  define FD_MAX 1024
# endif

typedef struct s_static_struct
{
	char	s_buf[BUFFER_SIZE];
	int		s_int;
}				t_s_struct;

char			*get_next_line(int fd);
size_t			ft_strlen(const char *s);
unsigned int	ft_strlcpy(char *dest, const char *src, size_t size);
size_t			ft_strlcat(char *dest, const char *src, size_t size);
char			*ft_strjoin(char const *s1, char const *s2);
char			*ft_strdup(char *src);
int				handle_read(int fd, char	*buf, int *s_int);
int				first_read_n_checks(int fd, int *s_int, char *buffer);
char			*get_seg(int start, int end, char	*buf);
char			*safe_join(char *result, char *add);
int				iteration(int *i, t_s_struct *s_struct, char **r, int fd);

#endif