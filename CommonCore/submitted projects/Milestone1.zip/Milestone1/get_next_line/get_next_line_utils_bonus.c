/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line_utils_bonus.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchiam <rchiam@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/04 21:06:49 by rchiam            #+#    #+#             */
/*   Updated: 2025/07/04 21:07:16 by rchiam           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line_bonus.h"

size_t	ft_strlen(const char *s)
{
	int	i;

	i = 0;
	while (s[i] != '\0')
		i++;
	return (i);
}

char	*ft_strjoin(char const *s1, char const *s2)
{
	size_t	len;
	char	*output;
	int		i;
	int		s_len;

	s_len = ft_strlen(s1);
	len = s_len + ft_strlen(s2) + 1;
	output = malloc (len * sizeof(char));
	if (output == NULL)
		return (NULL);
	i = 0;
	while (s1[i])
	{
		output[i] = s1[i];
		i++;
	}
	while (s2[i - s_len])
	{
		output[i] = s2[i - s_len];
		i++;
	}
	output[i] = '\0';
	return (output);
}

char	*ft_strdup(char *src)
{
	char	*dest;
	int		len;
	int		i;

	len = ft_strlen(src) + 1;
	dest = (char *)malloc(sizeof(char) * len);
	if (dest == NULL)
		return (NULL);
	i = 0;
	while (i < len && src[i] != '\0')
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (dest);
}

char	*safe_join(char *result, char *add)
{
	char	*temp;

	if (!result)
		return (NULL);
	if (!add)
	{
		free(result);
		return (NULL);
	}
	temp = result;
	result = ft_strjoin(temp, add);
	free(temp);
	free(add);
	return (result);
}
